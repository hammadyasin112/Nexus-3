
import React, { useState } from 'react';
import { InterviewType, Difficulty, InterviewConfig, InteractionMode } from './types';

interface Props {
  onStart: (config: InterviewConfig) => void;
}

const InterviewSetup: React.FC<Props> = ({ onStart }) => {
  const [type, setType] = useState<InterviewType>(InterviewType.JOB);
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.INTERMEDIATE);
  const [mode, setMode] = useState<InteractionMode>(InteractionMode.TEXT);
  const [field, setField] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!field) return;
    onStart({ type, difficulty, field, mode });
  };

  const getIcon = (t: InterviewType) => {
    switch (t) {
      case InterviewType.JOB: return (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
      );
      case InterviewType.SCHOLARSHIP: return (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 14l9-5-9-5-9 5 9 5z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"></path></svg>
      );
      case InterviewType.UNIVERSITY: return (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
      );
    }
  };

  return (
    <div className="max-w-6xl mx-auto w-full animate-in fade-in slide-in-from-bottom-12 duration-1000 py-8 lg:py-16">
      <div className="text-center mb-16">
        <div className="inline-block px-5 py-2 bg-sky-500/10 border border-sky-500/20 rounded-full mb-6">
           <span className="text-[10px] font-black text-sky-400 uppercase tracking-[0.5em]">Simulation Protocol v2.5</span>
        </div>
        <h2 className="text-6xl lg:text-7xl font-black text-white mb-6 tracking-tighter">Mission Config</h2>
        <p className="text-xl text-slate-500 font-medium max-w-2xl mx-auto leading-relaxed">Prepare for high-fidelity communication analysis across scholarship, job, and academic trajectories.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Object.values(InterviewType).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setType(t)}
              className={`relative p-10 rounded-[3rem] border transition-all duration-500 text-left group overflow-hidden ${
                type === t 
                  ? 'border-sky-500/50 bg-sky-500/5 selection-glow scale-[1.02]' 
                  : 'border-white/5 bg-slate-900/40 hover:border-white/10'
              }`}
            >
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-8 transition-all duration-500 ${type === t ? 'bg-sky-500 text-white shadow-[0_0_30px_rgba(56,189,248,0.4)]' : 'bg-white/5 text-slate-500 group-hover:bg-white/10 group-hover:text-slate-300'}`}>
                {getIcon(t)}
              </div>
              <h4 className={`text-sm font-black uppercase tracking-[0.2em] mb-2 transition-colors ${type === t ? 'text-white' : 'text-slate-500'}`}>{t}</h4>
              <p className="text-[10px] text-slate-600 font-bold leading-relaxed uppercase tracking-widest">Protocol Type {t[0]}</p>
              {type === t && <div className="absolute top-0 right-0 w-16 h-16 bg-sky-500/10 rounded-bl-[4rem] flex items-center justify-center"><div className="w-2 h-2 bg-sky-400 rounded-full"></div></div>}
            </button>
          ))}
        </div>

        <div className="glass rounded-[4rem] p-12 border border-white/5 bg-slate-950/40 shadow-inner relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            
            {/* Operational Mode Section */}
            <div className="space-y-8">
              <div className="flex items-center gap-4">
                <div className="w-1 h-4 bg-sky-400 rounded-full"></div>
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.5em]">Operational Mode</label>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 h-full">
                {Object.values(InteractionMode).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMode(m)}
                    className={`h-40 px-8 rounded-[2.5rem] border text-[11px] font-black uppercase tracking-[0.2em] transition-all flex flex-col items-center justify-center gap-4 ${
                      mode === m 
                        ? 'border-sky-500 bg-sky-500/10 text-sky-400 shadow-[0_0_20px_rgba(56,189,248,0.15)] ring-1 ring-sky-500/20' 
                        : 'border-white/5 bg-slate-900/60 text-slate-600 hover:text-slate-400 hover:border-white/10'
                    }`}
                  >
                    <div className={`p-3 rounded-xl transition-colors ${mode === m ? 'bg-sky-500/20' : 'bg-white/5'}`}>
                      {m === InteractionMode.VOICE ? (
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path></svg>
                      ) : (
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>
                      )}
                    </div>
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Simulation Intensity Section */}
            <div className="space-y-8 flex flex-col">
              <div className="flex items-center gap-4">
                <div className="w-1 h-4 bg-indigo-500 rounded-full"></div>
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.5em]">Simulation Intensity</label>
              </div>
              <div className="flex flex-col gap-3 flex-grow justify-center">
                {Object.values(Difficulty).map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setDifficulty(d)}
                    className={`w-full py-6 rounded-2xl border text-[11px] font-black uppercase tracking-[0.2em] transition-all text-left px-10 flex justify-between items-center group/btn ${
                      difficulty === d 
                        ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400 ring-1 ring-indigo-500/20' 
                        : 'border-white/5 bg-slate-900/60 text-slate-600 hover:text-slate-400 hover:border-white/10'
                    }`}
                  >
                    <span className="flex items-center gap-4">
                      <span className={`w-2 h-2 rounded-full transition-colors ${difficulty === d ? 'bg-indigo-400 animate-pulse' : 'bg-slate-800'}`}></span>
                      {d} LEVEL
                    </span>
                    <span className={`text-[10px] font-bold opacity-40 group-hover/btn:opacity-100 transition-opacity ${difficulty === d ? 'text-indigo-400' : 'text-slate-700'}`}>
                      {d === Difficulty.ADVANCED ? '+++ Critical' : d === Difficulty.INTERMEDIATE ? '++ Normal' : '+ Passive'}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-16 pt-12 border-t border-white/5 space-y-8">
            <div className="flex items-center gap-4">
              <div className="w-1 h-4 bg-emerald-500 rounded-full"></div>
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.5em]">Industry/Focus Descriptor</label>
            </div>
            <div className="relative group">
              <div className="absolute inset-y-0 left-8 flex items-center pointer-events-none group-focus-within:text-sky-400 text-slate-700 transition-colors">
                 <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
              </div>
              <input
                type="text"
                required
                placeholder="Ex: Senior Quantitative Researcher or International Law Scholar"
                className="w-full bg-slate-950/80 border border-white/10 pl-20 pr-10 py-8 rounded-[2.5rem] text-white placeholder-slate-800 focus:ring-2 focus:ring-sky-500/50 outline-none transition-all font-bold text-2xl shadow-inner focus:border-sky-500/50"
                value={field}
                onChange={(e) => setField(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Updated smaller button */}
        <div className="flex justify-center mt-12">
          <button
            type="submit"
            className="px-14 h-14 bg-white text-slate-950 font-extrabold rounded-full transition-all hover:scale-[1.03] hover:bg-sky-400 active:scale-[0.98] shadow-2xl flex items-center justify-center gap-5 text-xs uppercase tracking-[0.2em] group"
          >
            Initialize Protocol
            <div className="w-8 h-8 rounded-full bg-slate-950 text-white flex items-center justify-center group-hover:translate-x-2 transition-transform shadow-lg">
               <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
            </div>
          </button>
        </div>
      </form>
    </div>
  );
};

export default InterviewSetup;
