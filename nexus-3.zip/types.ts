
export enum InterviewType {
  SCHOLARSHIP = 'Scholarship',
  JOB = 'Job',
  UNIVERSITY = 'University Admission'
}

export enum Difficulty {
  BEGINNER = 'Beginner',
  INTERMEDIATE = 'Intermediate',
  ADVANCED = 'Advanced'
}

export enum InteractionMode {
  TEXT = 'Text Protocol',
  VOICE = 'Voice Interaction'
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  analysis?: TurnAnalysis;
}

export interface TurnAnalysis {
  confidence: number;
  clarity: number;
  grammar: string;
  tone: string;
  structure: string;
  score: number;
}

export interface VisionAnalysis {
  suggestion: string;
  postureScore: number;
  isCorrect: boolean;
}

export interface InterviewConfig {
  type: InterviewType;
  difficulty: Difficulty;
  field: string;
  mode: InteractionMode;
}

export interface InterviewReport {
  overallScore: number;
  globalReadinessScore: number;
  strengths: string[];
  weaknesses: string[];
  improvementTips: string[];
  sampleImprovedAnswers: { original: string; improved: string }[];
  summary: string;
  history?: Message[];
}

// --- Education Project Types ---

export type MoodType = 'Demotivated' | 'Anxious' | 'Burnt Out' | 'Overwhelmed' | 'Confident' | 'Neutral';

export interface EducationResult {
  reflection: string;
  learningInsight: string;
  quote: string;
  microAction: string;
  reframe: string;
}

// --- Design Project Types ---

export interface ColorData {
  hex: string;
  rgb: string;
  reasoning: string;
  usage: string;
}

export interface DesignResult {
  intentSummary: string;
  colors: {
    primary: ColorData;
    secondary: ColorData;
    accent: ColorData;
    neutral: ColorData;
  };
  accessibility: string;
  psychologyInsight: string;
  assessment?: {
    mismatches: string[];
    suggestions: string[];
  };
}

// --- Cybersecurity Project Types ---

export type SocialContext = 'KNOWN' | 'UNKNOWN' | 'UNSURE';

export interface ThreatSignal {
  label: string;
  score: number; // 0-100
  detected: boolean;
}

export interface CybersecurityResult {
  confidenceScore: number;
  signals: {
    urgencyManipulation: number;
    fearTrigger: boolean;
    authorityClaim: boolean;
    identityMismatch: boolean;
    emotionalManipulation: boolean;
  };
  scamPatterns: {
    type: string;
    reason: string;
  }[];
  evidence: string[];
  recommendedActions: string[];
  psychologyInsight: string;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

// --- Health Project Types ---

export interface HealthInputs {
  sleep: number;
  stress: number;
  screenTime: number;
  activity: number;
  diet: 'balanced' | 'average' | 'poor';
  water: number;
  mood: 'positive' | 'neutral' | 'low';
}

export interface HealthResult {
  horizon: number;
  energyVitality: number;
  mentalClarity: number;
  recoveryQuality: number;
  burnoutRisk: 'LOW' | 'MODERATE' | 'HIGH';
  emotionalBalance: 'LOW' | 'MODERATE' | 'HIGH';
  trajectoryAnalysis: string;
  currentPathOutcome: string;
  improvedPathOutcome: string;
  futureSelfMessage: string;
}

export enum PlatformView {
  DASHBOARD = 'DASHBOARD',
  COMMUNICATION = 'COMMUNICATION',
  EDUCATION = 'EDUCATION',
  DESIGN = 'DESIGN',
  CYBERSECURITY = 'CYBERSECURITY',
  HEALTH = 'HEALTH'
}
