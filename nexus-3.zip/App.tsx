
import React, { useState } from 'react';
import Layout from './components/Layout.tsx';
import Dashboard from './components/Dashboard.tsx';
import EducationMotivator from './components/EducationMotivator.tsx';
import DesignStrategyEngine from './components/DesignStrategyEngine.tsx';
import CybersecurityLens from './components/CybersecurityLens.tsx';
import FutureYouHealth from './components/FutureYouHealth.tsx';
import InterviewSetup from './InterviewSetup.tsx';
import ChatInterface from './components/ChatInterface.tsx';
import AudioInterface from './components/AudioInterface.tsx';
import ReportCard from './components/ReportCard.tsx';
import { InterviewConfig, Message, InterviewReport, InteractionMode, PlatformView } from './types.ts';
import { generateReport } from './components/geminiService.ts';

// Safety check for process.env
if (typeof (window as any).process === 'undefined') {
  (window as any).process = { env: {} };
}

enum AppStep {
  SETUP,
  INTERVIEW,
  LOADING_REPORT,
  REPORT
}

const App: React.FC = () => {
  const [view, setView] = useState<PlatformView>(PlatformView.DASHBOARD);
  const [step, setStep] = useState<AppStep>(AppStep.SETUP);
  const [config, setConfig] = useState<InterviewConfig | null>(null);
  const [report, setReport] = useState<InterviewReport | null>(null);
  const [history, setHistory] = useState<Message[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleStartInterview = async (selectedConfig: InterviewConfig) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      stream.getTracks().forEach(track => track.stop());
      setConfig(selectedConfig);
      setHistory([]);
      setError(null);
      setStep(AppStep.INTERVIEW);
    } catch (err: any) {
      setError("Hardware Access Required for Simulation.");
    }
  };

  const handleFinishInterview = async (currentHistory: Message[]) => {
    if (!config) return;
    setHistory(currentHistory);
    setStep(AppStep.LOADING_REPORT);
    try {
      const result = await generateReport(config, currentHistory);
      setReport({ ...result, history: currentHistory });
      setStep(AppStep.REPORT);
    } catch (err: any) {
      setError("Synthesis failed.");
      setStep(AppStep.SETUP);
    }
  };

  const goHome = () => {
    setView(PlatformView.DASHBOARD);
    setStep(AppStep.SETUP);
    setReport(null);
    setConfig(null);
  };

  return (
    <Layout>
      <div className="mb-8">
        {view !== PlatformView.DASHBOARD && (
          <button 
            onClick={goHome}
            className="flex items-center gap-3 text-[10px] font-black text-slate-500 uppercase tracking-widest hover:text-white transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Return to Lab Hub
          </button>
        )}
      </div>

      {error && (
        <div className="mb-8 p-5 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-black uppercase tracking-[0.2em] rounded-2xl text-center">
          {error}
          <button onClick={() => setError(null)} className="ml-4 opacity-40 hover:opacity-100 transition-opacity underline">DISMISS</button>
        </div>
      )}

      {view === PlatformView.DASHBOARD && <Dashboard onSelect={setView} />}
      {view === PlatformView.EDUCATION && <EducationMotivator />}
      {view === PlatformView.DESIGN && <DesignStrategyEngine />}
      {view === PlatformView.CYBERSECURITY && <CybersecurityLens />}
      {view === PlatformView.HEALTH && <FutureYouHealth />}

      {view === PlatformView.COMMUNICATION && (
        <>
          {step === AppStep.SETUP && <InterviewSetup onStart={handleStartInterview} />}
          {step === AppStep.INTERVIEW && config && (
            config.mode === InteractionMode.TEXT 
              ? <ChatInterface config={config} onFinish={handleFinishInterview} /> 
              : <AudioInterface config={config} onFinish={handleFinishInterview} />
          )}
          {step === AppStep.LOADING_REPORT && (
            <div className="flex-grow flex flex-col items-center justify-center space-y-12 py-32 animate-in fade-in duration-1000">
              <div className="relative w-32 h-32 animate-pulse">
                <div className="absolute inset-0 border-[8px] border-white/5 rounded-full"></div>
                <div className="absolute inset-0 border-[8px] border-sky-500 rounded-full border-t-transparent animate-spin"></div>
              </div>
              <h3 className="text-3xl font-black text-white tracking-tight">Synthesizing Protocol...</h3>
            </div>
          )}
          {step === AppStep.REPORT && report && config && (
            <ReportCard report={report} config={config} onRestart={() => setStep(AppStep.SETUP)} />
          )}
        </>
      )}
    </Layout>
  );
};

export default App;
