
# AI Interview Communication Simulator

A high-performance React application designed to transform how students and professionals prepare for high-stakes interviews. Built for the Google Gemini hackathon.

## Core Value Proposition
Traditional interview prep involves static lists of questions. This simulator uses **Gemini 3's advanced reasoning** to create a dynamic, adaptive experience that mimics the pressure and flow of a real human interview.

## Tech Stack
- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Visualization**: Recharts (for performance analytics)
- **AI Engine**: Google Gemini API (`gemini-3-flash-preview` for real-time interaction, `gemini-3-pro-preview` for deep-thinking report generation)
- **Architecture**: State-driven SPA with robust TypeScript typing for reliable AI response parsing.

## Key Features
1. **Dynamic Questioning Engine**: Gemini analyzes your previous response's depth and confidence to choose the next probing question.
2. **Real-Time Turn Analysis**: Instant feedback on grammar, clarity, tone, and confidence after every answer.
3. **Adaptive Personality**: The AI interviewer becomes tougher or more supportive based on your chosen difficulty level.
4. **Comprehensive Final Report**: A deep-dive analysis including strengths, weaknesses, sample improved answers, and a "Global Readiness Score".

## Architecture Flow
1. **Setup**: User defines Context (Job/Scholarship), Role (CS/Business), and Level (Beginner/Advanced).
2. **System Role-Play**: Gemini is initialized with a specialized system instruction defining its interviewer persona.
3. **The Loop**: 
   - User inputs text.
   - Gemini receives conversation history.
   - Gemini returns structured JSON containing:
     - The next logical question.
     - Real-time linguistic and structural analysis.
4. **Final Synthesis**: Gemini 3 Pro uses thinking tokens to generate a massive, structured feedback report.

## How to Run
1. Ensure `process.env.API_KEY` is configured in your environment.
2. Launch the application.
3. Choose "Job Interview" -> "Advanced" -> "Senior Software Engineer" to experience the peak challenge of the model.

---
*Built with passion for human communication and AI excellence.*
