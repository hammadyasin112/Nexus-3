
import React, { useState, useRef, useEffect } from 'react';
import { Message, InterviewConfig, TurnAnalysis, VisionAnalysis } from '../types';
import { getNextTurn, analyzeVision } from './geminiService';

interface Props {
  config: InterviewConfig;
  onFinish: (history: Message[]) => void;
}

const ChatInterface: React.FC<Props> = ({ config, onFinish }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastAnalysis, setLastAnalysis] = useState<TurnAnalysis | null>(null);
  const [visionFeedback, setVisionFeedback] = useState<VisionAnalysis | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const visionTimerRef = useRef<number | null>(null);

  const initInterview = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const firstTurn = await getNextTurn(config, []);
      if (firstTurn && firstTurn.question) {
        setMessages([{ role: 'model', text: firstTurn.question }]);
        if (firstTurn.analysis) setLastAnalysis(firstTurn.analysis);
      } else {
        throw new Error("Failed to generate initial question.");
      }
    } catch (err) {
      console.error(err);
      setError("Failed to initialize interview. Please check your network and try again.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    initInterview();

    // Init Camera
    navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
      if (videoRef.current) videoRef.current.srcObject = stream;
    }).catch(err => console.warn("Camera blocked or missing", err));

    // Vision Loop
    visionTimerRef.current = window.setInterval(async () => {
      if (videoRef.current && canvasRef.current) {
        const canvas = canvasRef.current;
        const video = videoRef.current;
        if (video.videoWidth > 0) {
          canvas.width = 320; 
          canvas.height = (video.videoHeight / video.videoWidth) * 320;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const frame = canvas.toDataURL('image/jpeg', 0.4).split(',')[1];
            analyzeVision(frame).then(setVisionFeedback).catch(() => {});
          }
        }
      }
    }, 5000);

    return () => {
      if (visionTimerRef.current) window.clearInterval(visionTimerRef.current);
      const stream = videoRef.current?.srcObject as MediaStream;
      stream?.getTracks().forEach(t => t.stop());
    };
  }, [config]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', text: input };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput('');
    setIsLoading(true);
    setError(null);

    try {
      const nextTurn = await getNextTurn(config, updatedMessages);
      setMessages(prev => [...prev, { role: 'model', text: nextTurn.question }]);
      if (nextTurn.analysis) setLastAnalysis(nextTurn.analysis);
    } catch (err) {
      console.error(err);
      setError("The protocol was interrupted. Try sending your response again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-8 h-screen lg:h-[82vh] animate-in fade-in duration-1000 overflow-hidden">
      {/* Simulation Terminal */}
      <div className="flex-grow flex flex-col glass rounded-[2.5rem] overflow-hidden border border-white/5 shadow-2xl relative">
        <div className="px-8 py-6 border-b border-white/5 flex justify-between items-center bg-slate-900/40 z-10">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center">
              <div className={`w-1.5 h-1.5 rounded-full bg-sky-400 ${isLoading ? 'animate-ping' : 'animate-pulse'}`}></div>
            </div>
            <div>
              <h3 className="font-black text-white uppercase tracking-widest text-[10px]">Active Session</h3>
              <p className="text-[9px] text-slate-500 font-bold uppercase tracking-[0.2em]">{config.type} Protocol</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="w-20 h-12 rounded-lg overflow-hidden border border-white/10 shadow-lg relative group bg-slate-950">
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover scale-x-[-1]" />
              <canvas ref={canvasRef} className="hidden" />
              <div className="absolute inset-0 bg-sky-500/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </div>
            <button 
              onClick={() => onFinish(messages)}
              className="text-[9px] font-black uppercase tracking-widest px-6 py-2.5 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/20 hover:bg-rose-500 hover:text-white transition-all shadow-lg"
            >
              End Session
            </button>
          </div>
        </div>

        <div ref={scrollRef} className="flex-grow overflow-y-auto p-10 space-y-10 scroll-smooth bg-slate-950/20 custom-scrollbar">
          {messages.length === 0 && !isLoading && !error && (
            <div className="flex flex-col items-center justify-center h-full text-center opacity-20">
              <p className="text-[10px] font-black uppercase tracking-[0.5em]">Establishing Neural Link...</p>
            </div>
          )}
          
          {messages.map((m, idx) => (
            <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] lg:max-w-[70%] space-y-2`}>
                <span className={`text-[8px] font-black uppercase tracking-[0.3em] block ${m.role === 'user' ? 'text-right text-sky-500' : 'text-slate-600'}`}>
                  {m.role === 'user' ? 'Candidate Packet' : 'System Query'}
                </span>
                <div className={`rounded-2xl px-6 py-4 text-sm leading-relaxed font-medium transition-all ${
                  m.role === 'user' 
                    ? 'bg-sky-500 text-slate-950 rounded-tr-none shadow-lg shadow-sky-500/10' 
                    : 'bg-white/5 text-slate-200 rounded-tl-none border border-white/5 backdrop-blur-sm'
                }`}>
                  {m.text}
                </div>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start items-center gap-4 animate-pulse">
               <div className="bg-white/5 rounded-2xl px-6 py-4 border border-white/5">
                 <div className="flex gap-2">
                    <div className="w-1.5 h-1.5 bg-sky-400/40 rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-sky-400/60 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 bg-sky-400/40 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                 </div>
               </div>
               <span className="text-[9px] font-black text-slate-700 uppercase tracking-widest">Synthesizing Protocol...</span>
            </div>
          )}

          {error && (
            <div className="flex flex-col items-center gap-4 py-10 bg-rose-500/5 border border-rose-500/10 rounded-3xl mx-auto max-w-lg">
              <p className="text-[10px] font-black text-rose-400 uppercase tracking-widest text-center px-10 leading-relaxed">
                {error}
              </p>
              <button 
                onClick={messages.length === 0 ? initInterview : handleSend}
                className="px-6 py-2.5 bg-rose-500 text-white rounded-full font-black text-[9px] uppercase tracking-widest hover:scale-105 transition-transform active:scale-95"
              >
                Retry Request
              </button>
            </div>
          )}
        </div>

        {/* Live Posture Suggestions Bar */}
        {visionFeedback && (
          <div className={`px-8 py-3 border-t border-white/5 flex items-center justify-between transition-colors ${visionFeedback.isCorrect ? 'bg-emerald-500/5' : 'bg-amber-500/5 animate-pulse'}`}>
            <div className="flex items-center gap-3">
              <div className={`w-1.5 h-1.5 rounded-full ${visionFeedback.isCorrect ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-amber-500 shadow-[0_0_8px_#f59e0b]'}`}></div>
              <span className={`text-[9px] font-black uppercase tracking-widest ${visionFeedback.isCorrect ? 'text-emerald-500/80' : 'text-amber-500'}`}>
                Position Logic: {visionFeedback.suggestion}
              </span>
            </div>
            <span className="text-[8px] font-black text-slate-600 uppercase tracking-tighter">Bio-Metrics: {visionFeedback.postureScore}/10</span>
          </div>
        )}

        <form onSubmit={handleSend} className="p-6 bg-slate-900/60 border-t border-white/5 flex gap-4">
          <input
            autoFocus
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isLoading ? "AI is formulating..." : "Transmit response..."}
            disabled={isLoading}
            className="flex-grow bg-slate-950/50 border border-white/5 px-6 py-4 rounded-xl text-white placeholder-slate-800 focus:ring-1 focus:ring-sky-500/50 outline-none text-sm font-semibold transition-all disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="w-14 h-14 bg-white text-slate-950 rounded-xl flex items-center justify-center hover:bg-sky-400 hover:scale-105 active:scale-95 transition-all shadow-xl disabled:opacity-20 shrink-0"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 10l7-7m0 0l7 7m-7-7v18"></path></svg>
          </button>
        </form>
      </div>

      {/* Live Intelligence Sidebar */}
      <div className="w-full lg:w-[380px] h-full flex flex-col gap-6 shrink-0 overflow-y-auto lg:overflow-visible pr-1">
        <div className="glass rounded-[2.5rem] p-8 border border-white/5 flex flex-col h-full bg-slate-900/30 overflow-hidden shadow-2xl">
          <div className="flex justify-between items-center mb-10 shrink-0">
            <div className="flex flex-col">
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em]">Live Intelligence</h3>
              <div className="flex items-center gap-2 mt-1">
                <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${isLoading ? 'bg-amber-500 shadow-[0_0_8px_#f59e0b]' : 'bg-emerald-500 shadow-[0_0_8px_#10b981]'}`}></span>
                <span className={`text-[8px] font-black uppercase tracking-widest ${isLoading ? 'text-amber-500' : 'text-emerald-500'}`}>
                  {isLoading ? 'Neural Feed Busy' : 'Neural Feed Open'}
                </span>
              </div>
            </div>
            <div className="w-10 h-10 border border-white/5 rounded-2xl flex items-center justify-center bg-white/5">
                <svg className="w-4 h-4 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
            </div>
          </div>
          
          {lastAnalysis ? (
            <div className="flex-grow flex flex-col gap-8 animate-in fade-in slide-in-from-right-4 duration-700">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-6 bg-white/5 rounded-3xl border border-white/5 hover:border-sky-500/20 transition-colors group">
                  <span className="block text-[8px] uppercase font-black text-slate-500 tracking-[0.2em] mb-4 group-hover:text-sky-400">Confidence</span>
                  <div className="flex items-end gap-1">
                    <span className="text-4xl font-black text-white">{lastAnalysis.confidence}</span>
                    <span className="text-[10px] font-bold text-slate-800 mb-2">/10</span>
                  </div>
                </div>

                <div className="p-6 bg-white/5 rounded-3xl border border-white/5 hover:border-indigo-500/20 transition-colors group">
                  <span className="block text-[8px] uppercase font-black text-slate-500 tracking-[0.2em] mb-4 group-hover:text-indigo-400">Bio-Metrics</span>
                  <div className="flex items-end gap-1">
                    <span className={`text-4xl font-black ${visionFeedback?.isCorrect ? 'text-white' : 'text-amber-500'}`}>{visionFeedback?.postureScore ?? '--'}</span>
                    <span className="text-[10px] font-bold text-slate-800 mb-2">/10</span>
                  </div>
                </div>
              </div>

              <div className="flex-grow space-y-6 overflow-y-auto pr-2 custom-scrollbar">
                <div className="flex items-center justify-between p-5 bg-white/5 rounded-2xl border border-white/5">
                  <span className="text-[9px] uppercase font-black text-slate-600 tracking-widest">Sentiment Tone</span>
                  <span className="px-3 py-1 bg-sky-500/10 text-sky-400 rounded-full text-[9px] font-black uppercase tracking-tighter border border-sky-500/20">{lastAnalysis.tone}</span>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-1 h-3 bg-indigo-500 rounded-full"></div>
                    <label className="text-[9px] uppercase font-black text-slate-500 tracking-[0.2em]">Linguistic Polish</label>
                  </div>
                  <div className="p-5 bg-indigo-500/5 rounded-3xl border border-indigo-500/10 backdrop-blur-sm">
                    <p className="text-[11px] text-indigo-300 font-bold leading-relaxed italic">"{lastAnalysis.grammar}"</p>
                  </div>
                </div>

                <div className="space-y-4">
                   <div className="flex items-center gap-3">
                    <div className="w-1 h-3 bg-emerald-500 rounded-full"></div>
                    <label className="text-[9px] uppercase font-black text-slate-500 tracking-[0.2em]">Structure Logic</label>
                  </div>
                  <div className="p-5 bg-emerald-500/5 rounded-3xl border border-emerald-500/10 backdrop-blur-sm">
                    <p className="text-[10px] text-slate-400 font-medium leading-relaxed uppercase tracking-tight">{lastAnalysis.structure}</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-grow flex flex-col items-center justify-center text-center px-10">
              <div className="w-16 h-16 border border-white/5 rounded-full flex items-center justify-center mb-6 relative">
                 <div className="absolute inset-0 border border-sky-500/20 rounded-full animate-ping"></div>
                 <svg className="w-6 h-6 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
              </div>
              <h4 className="text-[10px] font-black text-slate-600 uppercase tracking-[0.4em] mb-4 leading-relaxed">System Initialization</h4>
              <p className="text-[9px] text-slate-800 font-bold uppercase tracking-widest leading-loose max-w-[180px]">
                Priming neural engines and posture bio-sensors.
              </p>
            </div>
          )}
          
          <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between opacity-50">
             <span className="text-[8px] font-black text-slate-700 uppercase tracking-widest">Protocol 2.5-F</span>
             <div className="flex gap-1">
                {[...Array(5)].map((_, i) => <div key={i} className="w-1 h-1 bg-sky-500/40 rounded-full"></div>)}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
