
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { InterviewConfig, Message, TurnAnalysis, VisionAnalysis } from '../types';
import { analyzeTurn, analyzeVision } from './geminiService';

interface Props {
  config: InterviewConfig;
  onFinish: (history: Message[]) => void;
}

const AudioInterface: React.FC<Props> = ({ config, onFinish }) => {
  const [active, setActive] = useState(false);
  const [transcript, setTranscript] = useState<Message[]>([]);
  const [currentTranscription, setCurrentTranscription] = useState('');
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [lastAnalysis, setLastAnalysis] = useState<TurnAnalysis | null>(null);
  const [visionFeedback, setVisionFeedback] = useState<VisionAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const transcriptRef = useRef<HTMLDivElement>(null);
  
  const pendingInputRef = useRef('');
  const pendingOutputRef = useRef('');
  const visionTimerRef = useRef<number | null>(null);

  // Auto-scroll transcript
  useEffect(() => {
    if (transcriptRef.current) {
      transcriptRef.current.scrollTo({ top: transcriptRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [transcript, currentTranscription]);

  const cleanup = () => {
    setActive(false);
    streamRef.current?.getTracks().forEach(t => t.stop());
    audioContextRef.current?.close();
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    if (visionTimerRef.current) window.clearInterval(visionTimerRef.current);
  };

  const captureFrame = () => {
    if (!videoRef.current || !canvasRef.current) return null;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (video.videoWidth === 0) return null;
    canvas.width = 320; 
    canvas.height = (video.videoHeight / video.videoWidth) * 320;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
  };

  const startSession = async () => {
    try {
      // Using process.env.API_KEY directly as per guidelines.
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const inputContext = new AudioContext({ sampleRate: 16000 });
      
      streamRef.current = await navigator.mediaDevices.getUserMedia({ 
        audio: { echoCancellation: true, noiseSuppression: true }, 
        video: { width: 640, height: 480 } // Moderate resolution for faster vision
      });
      
      if (videoRef.current) videoRef.current.srcObject = streamRef.current;
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setActive(true);
            setInitError(null);
            
            // Audio input processing
            const source = inputContext.createMediaStreamSource(streamRef.current!);
            const scriptProcessor = inputContext.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              
              const base64 = btoa(String.fromCharCode(...new Uint8Array(int16.buffer)));
              sessionPromise.then(s => s.sendRealtimeInput({ 
                media: { data: base64, mimeType: 'audio/pcm;rate=16000' } 
              })).catch(() => {});
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputContext.destination);

            // Vision Loop
            visionTimerRef.current = window.setInterval(async () => {
              const frame = captureFrame();
              if (frame) {
                analyzeVision(frame).then(setVisionFeedback).catch(() => {});
                sessionPromise.then(s => s.sendRealtimeInput({
                  media: { data: frame, mimeType: 'image/jpeg' }
                })).catch(() => {});
              }
            }, 3000);
          },
          onmessage: async (msg: LiveServerMessage) => {
            // Handle audio output
            if (msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data) {
              setIsAiSpeaking(true);
              const base64 = msg.serverContent.modelTurn.parts[0].inlineData.data;
              const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
              const dataInt16 = new Int16Array(bytes.buffer);
              const buffer = audioContextRef.current!.createBuffer(1, dataInt16.length, 24000);
              const channelData = buffer.getChannelData(0);
              for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
              
              const source = audioContextRef.current!.createBufferSource();
              source.buffer = buffer;
              source.connect(audioContextRef.current!.destination);
              
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioContextRef.current!.currentTime);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              
              source.onended = () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsAiSpeaking(false);
              };
              sourcesRef.current.add(source);
            }

            // Real-time transcription updates
            if (msg.serverContent?.outputTranscription) {
              pendingOutputRef.current += msg.serverContent.outputTranscription.text;
              setCurrentTranscription(`AI: ${pendingOutputRef.current}`);
            } else if (msg.serverContent?.inputTranscription) {
              pendingInputRef.current += msg.serverContent.inputTranscription.text;
              setCurrentTranscription(`You: ${pendingInputRef.current}`);
            }

            // Turn Lifecycle
            if (msg.serverContent?.turnComplete) {
              const userText = pendingInputRef.current.trim();
              const modelText = pendingOutputRef.current.trim();

              if (userText && modelText) {
                setIsAnalyzing(true);
                analyzeTurn(userText, modelText).then(analysis => {
                  setLastAnalysis(analysis);
                  setTranscript(prev => [...prev, 
                    { role: 'user', text: userText, analysis }, 
                    { role: 'model', text: modelText }
                  ]);
                }).catch(() => {
                  setTranscript(prev => [...prev, { role: 'user', text: userText }, { role: 'model', text: modelText }]);
                }).finally(() => setIsAnalyzing(false));
              } else if (modelText) {
                setTranscript(prev => [...prev, { role: 'model', text: modelText }]);
              }

              pendingInputRef.current = '';
              pendingOutputRef.current = '';
              setCurrentTranscription('');
            }
          },
          onerror: (err: any) => {
            console.error("Live Session Error:", err);
            const msg = err?.message || "Link interrupted.";
            if (msg.includes("Permission denied")) {
              setInitError("API Tier Restriction: Your API key project may not have access to the Multimodal Live API. Try selecting a different project or use Text Mode.");
            } else {
              setInitError(msg);
            }
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          },
          systemInstruction: `You are an expert interviewer in ${config.field}. Be professional, concise, and challenging. Use vision to monitor the candidate's presence.`
        }
      });
    } catch (err: any) {
      console.error(err);
      setInitError("Hardware Error: Could not link sensors. Please check camera/mic permissions.");
    }
  };

  const handleManualFinish = () => {
    onFinish(transcript);
  };

  useEffect(() => {
    startSession();
    return cleanup;
  }, []);

  if (initError) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center animate-in fade-in duration-700 max-w-2xl mx-auto px-6">
        <div className="w-16 h-16 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-center justify-center mb-8 shadow-[0_0_30px_rgba(244,63,94,0.1)]">
          <svg className="w-8 h-8 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
        </div>
        <h3 className="text-2xl font-black text-white mb-4 uppercase tracking-tighter">Connection Failure</h3>
        <p className="text-slate-500 font-medium mb-12 leading-relaxed">{initError}</p>
        <div className="flex flex-wrap justify-center gap-4">
          <button onClick={() => window.location.reload()} className="px-8 py-4 bg-white text-slate-950 rounded-full font-black text-[10px] uppercase tracking-widest hover:bg-sky-400 transition-all">Retry Link</button>
          <button onClick={() => window.location.href='/'} className="px-8 py-4 glass border-white/10 text-slate-400 rounded-full font-black text-[10px] uppercase tracking-widest">Return to Menu</button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-8 h-screen lg:h-[82vh] animate-in fade-in duration-1000 overflow-hidden">
      {/* Simulation Central Hub */}
      <div className="flex-grow flex flex-col items-center justify-center glass rounded-[3rem] border border-white/5 relative bg-slate-950/40 overflow-hidden min-h-[400px] shadow-2xl">
        
        {/* Cam Mirror */}
        <div className="absolute top-8 right-8 w-44 aspect-video rounded-2xl overflow-hidden border border-white/10 shadow-3xl z-30 group transition-all hover:scale-105">
          <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover scale-x-[-1]" />
          <div className="absolute inset-0 bg-slate-950/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse mb-2"></div>
            <span className="text-[7px] font-black text-white uppercase tracking-widest">Vision Protocol Active</span>
          </div>
        </div>
        <canvas ref={canvasRef} className="hidden" />

        <div className="relative">
          <div className={`absolute -inset-24 bg-sky-500/10 rounded-full blur-[100px] transition-all duration-1000 ${isAiSpeaking ? 'opacity-100 scale-125' : 'opacity-30 scale-100'}`}></div>
          <div className={`relative w-64 h-64 rounded-full border border-white/5 flex flex-col items-center justify-center bg-slate-900/60 shadow-inner transition-all duration-500 ${isAiSpeaking ? 'scale-110' : 'scale-100'}`}>
            <div className="flex gap-2 items-end h-12 mb-8 px-4">
              {[...Array(12)].map((_, i) => (
                <div 
                  key={i} 
                  className={`w-1.5 bg-sky-500 rounded-full transition-all duration-150 ${isAiSpeaking ? 'animate-[subtle-pulse_0.6s_infinite]' : 'h-1.5 opacity-10'}`}
                  style={{ 
                    height: isAiSpeaking ? `${30 + Math.random() * 70}%` : '6px',
                    animationDelay: `${i * 0.05}s`
                  }}
                ></div>
              ))}
            </div>
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.5em] text-glow">
              {isAiSpeaking ? 'Broadcasting' : 'Listening'}
            </p>
          </div>
        </div>

        {/* Real-time Captions */}
        <div className="absolute bottom-12 inset-x-0 px-12 text-center space-y-6">
           {visionFeedback && visionFeedback.postureScore > 0 && (
             <div className={`mx-auto max-w-lg py-2.5 px-6 rounded-full border border-white/5 transition-all duration-700 ${visionFeedback.isCorrect ? 'bg-emerald-500/5 text-emerald-400' : 'bg-amber-500/5 text-amber-400 animate-pulse'}`}>
               <div className="flex items-center justify-center gap-3">
                 <div className={`w-1 h-1 rounded-full ${visionFeedback.isCorrect ? 'bg-emerald-500' : 'bg-amber-500'}`}></div>
                 <span className="text-[9px] font-black uppercase tracking-[0.2em]">{visionFeedback.suggestion}</span>
               </div>
             </div>
           )}
           <div className="glass-dark rounded-3xl py-8 px-10 border border-white/5 mx-auto max-w-2xl shadow-2xl min-h-[90px] flex items-center justify-center transition-all">
             <p className="text-sm font-semibold text-slate-300 italic leading-relaxed">
               {currentTranscription || "Awaiting acoustic neural signal..."}
             </p>
           </div>
        </div>

        <button 
          onClick={handleManualFinish}
          className="absolute top-8 left-8 px-5 py-2.5 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-full font-black uppercase text-[8px] tracking-widest hover:bg-rose-500 hover:text-white transition-all z-20"
        >
          End Protocol
        </button>
      </div>

      {/* Intelligence Sidebar */}
      <div className="w-full lg:w-[420px] h-full flex flex-col shrink-0 overflow-hidden">
        <div className="glass rounded-[3rem] p-10 border border-white/5 flex flex-col h-full bg-slate-950/20 relative shadow-2xl">
           
           <div className="shrink-0 mb-10">
             <div className="flex justify-between items-center mb-8">
                <div className="flex flex-col">
                  <h3 className="text-[11px] font-black text-white uppercase tracking-[0.4em]">Live Intelligence</h3>
                  <div className="flex items-center gap-2 mt-2">
                    <span className={`w-1.5 h-1.5 rounded-full ${isAnalyzing ? 'bg-amber-500 animate-pulse shadow-[0_0_8px_#f59e0b]' : 'bg-emerald-500 shadow-[0_0_8px_#10b981]'}`}></span>
                    <span className={`text-[8px] font-black uppercase tracking-[0.3em] ${isAnalyzing ? 'text-amber-500' : 'text-emerald-500'}`}>
                      {isAnalyzing ? 'Parsing Turn' : 'Neural Feed Stable'}
                    </span>
                  </div>
                </div>
                <div className="w-10 h-10 border border-white/5 rounded-2xl flex items-center justify-center bg-white/5 shadow-inner">
                   <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                </div>
             </div>

             <div className="grid grid-cols-2 gap-4">
                <div className="p-6 bg-slate-950/60 rounded-3xl border border-white/5 group hover:border-sky-500/30 transition-all">
                  <span className="block text-[8px] uppercase font-black text-slate-600 tracking-widest mb-3">Confidence</span>
                  <div className="flex items-end gap-1">
                    <span className="text-4xl font-black text-white">{lastAnalysis?.confidence ?? '--'}</span>
                    <span className="text-[10px] font-bold text-slate-800 mb-1.5">/10</span>
                  </div>
                </div>
                <div className="p-6 bg-slate-950/60 rounded-3xl border border-white/5 group hover:border-indigo-500/30 transition-all">
                  <span className="block text-[8px] uppercase font-black text-slate-600 tracking-widest mb-3">Posture Score</span>
                  <div className="flex items-end gap-1">
                    <span className={`text-4xl font-black ${(visionFeedback && visionFeedback.postureScore > 0) ? 'text-white' : 'text-slate-800'}`}>
                      {(visionFeedback && visionFeedback.postureScore > 0) ? visionFeedback.postureScore : '--'}
                    </span>
                    <span className="text-[10px] font-bold text-slate-800 mb-1.5">/10</span>
                  </div>
                </div>
             </div>
           </div>

           <div className="flex-grow flex flex-col overflow-hidden">
             <div className="flex items-center gap-3 mb-6 shrink-0 px-1">
               <div className="w-1 h-3 bg-slate-700 rounded-full"></div>
               <h4 className="text-[10px] font-black text-slate-600 uppercase tracking-[0.3em]">Neural Signal Log</h4>
             </div>
             
             <div ref={transcriptRef} className="flex-grow overflow-y-auto space-y-8 pr-4 custom-scrollbar">
                {transcript.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center opacity-20">
                     <p className="text-[10px] font-black uppercase tracking-widest leading-loose">Awaiting Vocal Protocol...</p>
                     <div className="w-12 h-12 rounded-full border border-white/10 border-t-sky-500 animate-spin mt-4"></div>
                  </div>
                ) : (
                  transcript.map((msg, i) => (
                    <div key={i} className={`flex flex-col gap-3 animate-in slide-in-from-bottom-2 duration-500 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                      <div className="flex items-center gap-2">
                        <span className={`text-[7px] font-black uppercase tracking-[0.2em] ${msg.role === 'user' ? 'text-sky-500' : 'text-slate-600'}`}>
                          {msg.role === 'user' ? 'Candidate Input' : 'System Query'}
                        </span>
                      </div>
                      <div className={`p-5 rounded-[1.5rem] text-[12px] font-medium leading-relaxed border transition-all ${
                        msg.role === 'user' 
                          ? 'bg-sky-500/5 text-sky-100 border-sky-500/10 rounded-tr-none' 
                          : 'bg-white/5 text-slate-300 border-white/5 rounded-tl-none'
                      }`}>
                        {msg.text}
                      </div>
                      {msg.analysis && (
                        <div className="flex items-center gap-4 px-2">
                          <span className="text-[8px] font-black text-sky-500/60 uppercase tracking-widest">Tone: {msg.analysis.tone}</span>
                          <span className="text-[8px] font-black text-emerald-500/60 uppercase tracking-widest">Score: {msg.analysis.score}/10</span>
                        </div>
                      )}
                    </div>
                  ))
                )}
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default AudioInterface;
