
import React, { useState, useEffect } from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [latency, setLatency] = useState(24);

  // Simulate realistic neural latency jitter
  useEffect(() => {
    const interval = setInterval(() => {
      setLatency(prev => {
        const jitter = Math.floor(Math.random() * 5) - 2;
        return Math.max(18, Math.min(32, prev + jitter));
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 glass border-b border-white/5 py-4">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center">
            {/* Rebranded Logo Area with Atomic 3 Icon */}
            <div className="flex items-center gap-4 group cursor-pointer" onClick={() => window.location.reload()}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                {/* Orbital Glow Effect */}
                <div className="absolute inset-0 bg-cyan-500/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                
                {/* SVG Atomic Logo */}
                <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 drop-shadow-[0_0_12px_rgba(56,189,248,0.5)]">
                  <defs>
                    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#38bdf8" />
                      <stop offset="100%" stopColor="#818cf8" />
                    </linearGradient>
                  </defs>
                  
                  {/* Orbits */}
                  <ellipse 
                    cx="50" cy="50" rx="44" ry="16" 
                    fill="none" 
                    stroke="url(#grad1)" 
                    strokeWidth="2.5" 
                    transform="rotate(-35 50 50)" 
                    className="opacity-90 group-hover:stroke-cyan-300 transition-colors"
                  />
                  <ellipse 
                    cx="50" cy="50" rx="44" ry="16" 
                    fill="none" 
                    stroke="#818cf8" 
                    strokeWidth="2" 
                    transform="rotate(45 50 50)" 
                    className="opacity-60 group-hover:opacity-100 transition-opacity"
                  />
                  <ellipse 
                    cx="50" cy="50" rx="44" ry="16" 
                    fill="none" 
                    stroke="#38bdf8" 
                    strokeWidth="1.5" 
                    transform="rotate(120 50 50)" 
                    className="opacity-40 group-hover:opacity-80 transition-opacity"
                  />
                  
                  {/* Center Number 3 */}
                  <text 
                    x="50" y="60" 
                    textAnchor="middle" 
                    fill="white" 
                    fontSize="36" 
                    fontWeight="900" 
                    className="tracking-tighter font-sans select-none"
                    style={{ textShadow: '0 0 10px rgba(255,255,255,0.5)' }}
                  >
                    3
                  </text>
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-black tracking-tight text-white leading-none">Nexus <span className="text-cyan-400">3</span></h1>
                <span className="text-[9px] text-slate-500 font-extrabold uppercase tracking-[0.2em]">One Core. Infinite Modules.</span>
              </div>
            </div>

            {/* Professional Telemetry Features */}
            <nav className="hidden md:flex items-center space-x-8">
              {/* Latency Monitor */}
              <div className="flex flex-col items-end">
                <span className="text-[7px] font-black text-slate-600 uppercase tracking-widest">Neural Latency</span>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-cyan-500 font-mono">{latency}ms</span>
                  <div className="flex gap-0.5 items-end h-2">
                    {[0.4, 0.7, 0.5, 0.9].map((h, i) => (
                      <div key={i} className="w-0.5 bg-cyan-500/40 rounded-full" style={{ height: `${h * 100}%` }}></div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="h-6 w-px bg-white/10"></div>

              {/* Station ID */}
              <div className="flex flex-col items-start">
                <span className="text-[7px] font-black text-slate-600 uppercase tracking-widest">Lab Station</span>
                <span className="text-[10px] font-black text-white tracking-widest uppercase">NEX-SYS-077</span>
              </div>

              <div className="h-6 w-px bg-white/10"></div>

              {/* Security Protocol */}
              <div className="flex items-center gap-3 px-4 py-2 bg-white/5 rounded-full border border-white/5 group hover:border-cyan-500/30 transition-all cursor-crosshair">
                <div className="relative">
                   <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                   <div className="absolute inset-0 w-2 h-2 rounded-full bg-emerald-500 animate-ping opacity-40"></div>
                </div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest group-hover:text-white transition-colors">Core: Optimized</span>
              </div>

              {/* Lab ID / Encrypted Session */}
              <div className="flex items-center gap-2">
                <svg className="w-3 h-3 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 00-2 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                <span className="text-[8px] font-mono text-slate-700 font-bold uppercase tracking-tighter">SEC_TOKEN_ACTIVE</span>
              </div>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow flex flex-col max-w-7xl w-full mx-auto px-6 lg:px-8 py-12 relative z-10">
        {children}
      </main>
      
      <footer className="glass border-t border-white/5 py-10 mt-auto">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">
            &copy; 2026 Nexus 3 Intelligence Lab • Core Architecture v3.1.0
          </p>
          <div className="flex gap-8">
            <span className="text-[8px] text-cyan-500/50 uppercase font-black tracking-widest flex items-center gap-2">
              <span className="w-1 h-1 bg-cyan-500 rounded-full animate-pulse"></span>
              Quantum Neural Link: Connected
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
