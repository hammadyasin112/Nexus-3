
import { GoogleGenAI, Type } from "@google/genai";
import { SYSTEM_INSTRUCTION, REPORT_PROMPT, EDUCATION_SYSTEM_PROMPT, DESIGN_SYSTEM_PROMPT, CYBERSECURITY_SYSTEM_PROMPT, HEALTH_SYSTEM_PROMPT } from "../constants.tsx";
import { InterviewConfig, Message, TurnAnalysis, InterviewReport, VisionAnalysis, MoodType, EducationResult, DesignResult, CybersecurityResult, SocialContext, HealthInputs, HealthResult } from "../types.ts";

// Initializing GoogleGenAI using process.env.API_KEY directly as per guidelines.
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeHealthSimulation = async (inputs: HealthInputs, horizon: number): Promise<HealthResult> => {
  const ai = getAI();
  const modelName = 'gemini-3-flash-preview';

  const prompt = `
    LIFESTYLE DATA:
    - Sleep: ${inputs.sleep} hrs/night
    - Stress: ${inputs.stress}/10
    - Screen Time: ${inputs.screenTime} hrs/day
    - Physical Activity: ${inputs.activity}/10
    - Diet Quality: ${inputs.diet}
    - Water Intake: ${inputs.water}/10
    - Primary Mood: ${inputs.mood}
    
    SIMULATION HORIZON: ${horizon} years into the future.
    
    Generate a wellness simulation projection. Compounding lifestyle impact over ${horizon} years.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        systemInstruction: HEALTH_SYSTEM_PROMPT,
        responseMimeType: "application/json"
      }
    });

    return { ...JSON.parse(response.text || '{}'), horizon };
  } catch (error) {
    console.error("Health Simulation Error:", error);
    throw error;
  }
};

export const analyzeCybersecurityThreat = async (message: string, context: SocialContext): Promise<CybersecurityResult> => {
  const ai = getAI();
  const modelName = 'gemini-3-flash-preview';

  const prompt = `
    SOCIAL CONTEXT: ${context}
    MESSAGE TO ANALYZE: "${message}"
    
    Perform a forensic cybersecurity analysis. Determine the threat confidence and provide evidence-based signals.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        systemInstruction: CYBERSECURITY_SYSTEM_PROMPT,
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Cybersecurity Analysis Error:", error);
    throw error;
  }
};

export const analyzeTurn = async (userText: string, modelText: string): Promise<TurnAnalysis> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [{ role: 'user', parts: [{ text: `Analyze the following interview turn and provide detailed metrics in JSON format.
Candidate's Answer: ${userText}
Interviewer's Question/Response: ${modelText}` }] }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          confidence: { type: Type.NUMBER, description: "Confidence score from 1-10" },
          clarity: { type: Type.NUMBER, description: "Clarity score from 1-10" },
          grammar: { type: Type.STRING, description: "A brief critique of the candidate's grammar" },
          tone: { type: Type.STRING, description: "The perceived emotional tone of the candidate" },
          structure: { type: Type.STRING, description: "A brief critique of the answer structure (e.g., STAR method compliance)" },
          score: { type: Type.NUMBER, description: "Overall turn score from 1-10" }
        },
        required: ["confidence", "clarity", "grammar", "tone", "structure", "score"]
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

export const analyzeDesignStrategy = async (intent: string, assessmentColors?: string): Promise<DesignResult> => {
  const ai = getAI();
  const modelName = 'gemini-3-flash-preview';

  const prompt = assessmentColors 
    ? `INTENT: ${intent}\nEXISTING COLORS TO ASSESS: ${assessmentColors}\n\nPerform an assessment and provide a corrected strategy.`
    : `PROJECT INTENT: ${intent}\n\nGenerate a new strategy from scratch.`;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        systemInstruction: DESIGN_SYSTEM_PROMPT,
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Design Strategy Error:", error);
    throw error;
  }
};

export const getNextTurn = async (config: InterviewConfig, history: Message[]): Promise<{ question: string; analysis: TurnAnalysis }> => {
  const ai = getAI();
  const modelName = 'gemini-3-flash-preview';
  const contents = history.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
  const response = await ai.models.generateContent({
    model: modelName,
    contents: contents.length > 0 ? contents : [{ role: 'user', parts: [{ text: 'Start.' }] }],
    config: { systemInstruction: SYSTEM_INSTRUCTION(config), responseMimeType: "application/json" }
  });
  return JSON.parse(response.text || '{}');
};

export const analyzeLearningState = async (mood: MoodType, reflection: string): Promise<EducationResult> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [{ role: 'user', parts: [{ text: reflection }] }],
    config: { systemInstruction: EDUCATION_SYSTEM_PROMPT(mood), responseMimeType: "application/json" }
  });
  return JSON.parse(response.text || '{}');
};

export const analyzeVision = async (base64Image: string): Promise<VisionAnalysis> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: { parts: [{ inlineData: { data: base64Image, mimeType: 'image/jpeg' } }, { text: "Assess posture." }] },
    config: { 
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          suggestion: { type: Type.STRING },
          postureScore: { type: Type.NUMBER },
          isCorrect: { type: Type.BOOLEAN }
        },
        required: ["suggestion", "postureScore", "isCorrect"]
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

export const generateReport = async (config: InterviewConfig, history: Message[]): Promise<InterviewReport> => {
  const ai = getAI();
  const transcript = history.map(m => `${m.role.toUpperCase()}: ${m.text}`).join('\n\n');
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: [{ role: 'user', parts: [{ text: transcript }] }],
    config: { 
      responseMimeType: "application/json", 
      thinkingConfig: { thinkingBudget: 4000 } 
    }
  });
  return JSON.parse(response.text || '{}');
};
