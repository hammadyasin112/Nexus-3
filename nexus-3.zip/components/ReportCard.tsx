
import React from 'react';
import { InterviewReport, InterviewConfig, Message } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

interface Props {
  report: InterviewReport;
  config: InterviewConfig;
  onRestart: () => void;
}

const ReportCard: React.FC<Props> = ({ report, config, onRestart }) => {
  const overallScore = report?.overallScore ?? 0;
  const globalReadinessScore = report?.globalReadinessScore ?? 0;
  const strengths = report?.strengths ?? [];
  const weaknesses = report?.weaknesses ?? [];
  const improvementTips = report?.improvementTips ?? [];
  const sampleImprovedAnswers = report?.sampleImprovedAnswers ?? [];
  const summary = report?.summary ?? "Analysis incomplete.";
  const history = report?.history ?? [];

  const trendData = history
    .filter(m => m.role === 'user' && m.analysis)
    .map((m, idx) => ({
      turn: `T${idx + 1}`,
      confidence: m.analysis?.confidence ?? 0,
      clarity: m.analysis?.clarity ?? 0,
    }));

  const scoreData = [
    { name: 'Score', value: overallScore },
    { name: 'Remaining', value: 100 - overallScore },
  ];

  const radarData = [
    { subject: 'Confidence', A: Math.max(...trendData.map(d => d.confidence), 5), fullMark: 10 },
    { subject: 'Clarity', A: Math.max(...trendData.map(d => d.clarity), 5), fullMark: 10 },
    { subject: 'Structure', A: 7, fullMark: 10 },
    { subject: 'Grammar', A: 8, fullMark: 10 },
    { subject: 'Relevance', A: 9, fullMark: 10 },
  ];

  const handleExport = () => {
    const markdown = `# Intelligence Report: ${config.field}\n\n## Summary\n${summary}\n\n## Scores\n- Score: ${overallScore}/100\n- Global Readiness: ${globalReadinessScore}%`;
    const blob = new Blob([markdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `InterviewerAI_Report.md`;
    a.click();
  };

  return (
    <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-12 duration-1000 pb-32">
      <div className="flex flex-col md:flex-row justify-between items-end gap-10">
        <div>
          <span className="text-[10px] font-black text-sky-400 uppercase tracking-[0.5em] mb-4 block underline underline-offset-8">Simulation Outcome</span>
          <h2 className="text-7xl font-black text-white tracking-tight">Executive Briefing</h2>
          <p className="text-slate-500 font-bold mt-2 uppercase tracking-widest text-xs">Analysis valid for {config.field}</p>
        </div>
        <div className="flex gap-4">
          <button onClick={handleExport} className="px-8 py-5 glass border-white/10 text-white rounded-3xl font-black text-[10px] uppercase tracking-widest hover:bg-white/5 transition-all active:scale-95 flex items-center gap-2">Export Protocol</button>
          <button onClick={onRestart} className="px-10 py-5 bg-white text-slate-950 rounded-3xl font-black text-[10px] uppercase tracking-widest hover:bg-sky-400 transition-all shadow-2xl active:scale-95">Reset Session</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-6 gap-6">
        {/* Aggregate Score Card */}
        <div className="md:col-span-2 glass p-10 rounded-[3rem] border border-white/5 flex flex-col items-center justify-center relative bg-gradient-to-b from-slate-900/40 to-slate-950/60">
          <div className="relative w-48 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={scoreData} cx="50%" cy="50%" innerRadius={70} outerRadius={90} dataKey="value" startAngle={90} endAngle={450} stroke="none">
                  <Cell fill="#38bdf8" />
                  <Cell fill="rgba(255,255,255,0.02)" />
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-6xl font-black text-white tracking-tighter">{overallScore}</span>
              <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Score</span>
            </div>
          </div>
          <div className="mt-8 flex gap-8">
             <div className="text-center">
                <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Readiness</span>
                <div className="text-xl font-black text-sky-400">{globalReadinessScore}%</div>
             </div>
             <div className="text-center">
                <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Intensity</span>
                <div className="text-xl font-black text-indigo-400">{config.difficulty[0]}</div>
             </div>
          </div>
        </div>

        {/* Momentum Chart */}
        <div className="md:col-span-4 glass p-10 rounded-[3rem] border border-white/5 flex flex-col bg-slate-900/40">
          <div className="flex justify-between items-center mb-10">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em]">Performance Momentum</span>
            <div className="flex gap-4 text-[8px] font-black uppercase tracking-widest">
              <div className="flex items-center gap-2 text-sky-400"><div className="w-2 h-2 rounded-full bg-sky-400"></div>Confidence</div>
              <div className="flex items-center gap-2 text-indigo-400"><div className="w-2 h-2 rounded-full bg-indigo-400"></div>Clarity</div>
            </div>
          </div>
          <div className="flex-grow min-h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="turn" stroke="#475569" fontSize={9} axisLine={false} tickLine={false} />
                <YAxis hide domain={[0, 10]} />
                <Tooltip contentStyle={{ backgroundColor: '#020617', border: '1px solid #1e293b', borderRadius: '16px' }} />
                <Line type="stepAfter" dataKey="confidence" stroke="#38bdf8" strokeWidth={3} dot={{ r: 4, fill: '#38bdf8' }} />
                <Line type="stepAfter" dataKey="clarity" stroke="#6366f1" strokeWidth={3} dot={{ r: 4, fill: '#6366f1' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Strategic Analysis */}
        <div className="glass p-12 rounded-[3.5rem] bg-slate-900/40 border border-white/5 space-y-12">
           <div className="grid grid-cols-1 gap-10">
              <div className="space-y-6">
                <span className="text-[10px] font-black text-sky-400 uppercase tracking-[0.4em] mb-2 block">Linguistic Strengths</span>
                {strengths.map((s, i) => (
                  <div key={i} className="flex gap-4 p-5 bg-white/5 rounded-2xl border border-white/5 text-sm text-slate-200 font-medium">
                    <span className="text-sky-500 font-black">✓</span> {s}
                  </div>
                ))}
              </div>
              <div className="space-y-6">
                <span className="text-[10px] font-black text-rose-400 uppercase tracking-[0.4em] mb-2 block">Optimisation Targets</span>
                {weaknesses.map((w, i) => (
                  <div key={i} className="flex gap-4 p-5 bg-white/5 rounded-2xl border border-white/5 text-sm text-slate-200 font-medium">
                    <span className="text-rose-500 font-black">!</span> {w}
                  </div>
                ))}
              </div>
           </div>
        </div>

        {/* Behavioral Radar and Action Plan */}
        <div className="flex flex-col gap-8">
          <div className="glass p-10 rounded-[3rem] border border-white/5 bg-slate-900/40 flex-grow">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-8 block">Competency Mapping</span>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="75%" data={radarData}>
                  <PolarGrid stroke="#1e293b" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#475569', fontSize: 9, fontWeight: 900 }} />
                  <Radar dataKey="A" stroke="#38bdf8" fill="#38bdf8" fillOpacity={0.1} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="glass p-10 rounded-[3rem] bg-indigo-500/5 border border-indigo-500/10">
             <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.4em] mb-6 block">Immediate Roadmap</span>
             <ul className="space-y-4">
               {improvementTips.map((tip, i) => (
                 <li key={i} className="text-xs text-slate-400 font-medium leading-relaxed flex gap-3">
                   <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0"></div>
                   {tip}
                 </li>
               ))}
             </ul>
          </div>
        </div>
      </div>

      {/* Transcript Log */}
      <div className="space-y-8">
        <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.5em] px-8">Audit Trail: Transcript Analysis</h3>
        <div className="grid grid-cols-1 gap-6">
           {history.filter(m => m.role === 'user').map((m, i) => (
             <div key={i} className="glass rounded-[2.5rem] p-10 border border-white/5 hover:border-sky-500/20 transition-all group">
                <div className="flex justify-between items-start mb-6">
                  <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Entry_{i+1}</span>
                  {m.analysis && <div className="text-[10px] font-black text-sky-400 border border-sky-400/20 px-3 py-1 rounded-full uppercase">Purity: {m.analysis.score}/10</div>}
                </div>
                <p className="text-lg text-slate-100 font-bold leading-relaxed mb-8">"{m.text}"</p>
                {m.analysis && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 border-t border-white/5">
                    <div>
                      <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest block mb-2">Structure Critique</span>
                      <p className="text-[10px] text-slate-400 font-medium leading-relaxed">{m.analysis.structure}</p>
                    </div>
                    <div>
                      <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest block mb-2">Linguistic Fix</span>
                      <p className="text-[10px] text-indigo-300 font-bold italic leading-relaxed">"{m.analysis.grammar}"</p>
                    </div>
                    <div>
                      <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest block mb-2">Emotional Tone</span>
                      <p className="text-[10px] text-slate-400 font-medium capitalize">{m.analysis.tone}</p>
                    </div>
                  </div>
                )}
             </div>
           ))}
        </div>
      </div>

      <div className="glass-dark p-20 rounded-[4rem] border border-white/10 text-center relative overflow-hidden">
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-sky-500 to-transparent opacity-50"></div>
        <span className="text-[10px] font-black text-slate-600 uppercase tracking-[0.6em] mb-10 block">Final Intelligence Brief</span>
        <p className="text-3xl font-black text-slate-100 leading-tight max-w-4xl mx-auto italic tracking-tight">
          "{summary}"
        </p>
      </div>
    </div>
  );
};

export default ReportCard;
